package com.example.bobbbbb;

import android.annotation.SuppressLint;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;


public class MainActivity extends AppCompatActivity {

    private EditText nameform;
    private EditText surnameform;
    private EditText emailform;
    private EditText phoneform;
    private EditText passform;
    private EditText passcheck;
    private Button submit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameform = findViewById(R.id.editTextName);
        surnameform = findViewById(R.id.editTextSurname);
        emailform = findViewById(R.id.editTextEmail);
        phoneform = findViewById(R.id.editPhone);
        passform = findViewById(R.id.editPass);
        passcheck = findViewById(R.id.editPassCheck);
        submit = findViewById(R.id.buttonSubmit);

        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String name = nameform.getText().toString().trim();
                String surname = surnameform.getText().toString().trim();
                String email = emailform.getText().toString().trim();
                String phone = phoneform.getText().toString().trim();
                String pass = passform.getText().toString().trim();
                String check = passcheck.getText().toString().trim();

                if(name.isEmpty()){
                    Toast.makeText(MainActivity.this, "Proszę wpisać imię",Toast.LENGTH_SHORT).show();
                }
                if(surname.isEmpty()){
                    Toast.makeText(MainActivity.this, "Proszę wpisać nazwisko",Toast.LENGTH_SHORT).show();
                }
                else if(email.isEmpty()){
                    Toast.makeText(MainActivity.this, "Proszę wpisać email",Toast.LENGTH_SHORT).show();
                }
                else if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Toast.makeText(MainActivity.this, "Niepoprawny adres email",Toast.LENGTH_SHORT).show();
                }
                else if() {
                    Toast.makeText(MainActivity.this, "Niepoprawny numer telefonu", Toast.LENGTH_SHORT).show(); //if na numer tel
                }
                else{
                    Toast.makeText(MainActivity.this, "Formularz przesłany poprawnie",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }


}